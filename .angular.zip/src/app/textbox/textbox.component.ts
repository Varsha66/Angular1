import { Component, OnInit } from '@angular/core';

   @Component({
     selector: 'app-textbox',
     templateUrl: './textbox.component.html',
     styleUrls: ['./textbox.component.css']
   })
   export class ColorChangerComponent implements OnInit {
     color: string = '';

     constructor() { }

     ngOnInit(): void {
     }
   }
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReadonlyDirective } from './readonly.directive';
import { NumbersonlyDirective } from './numbersonly.directive';
import { WhitespaceDirective } from './whitespace.directive';

@NgModule({
  declarations: [
    AppComponent,
    ReadonlyDirective,
    NumbersonlyDirective,
    WhitespaceDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
